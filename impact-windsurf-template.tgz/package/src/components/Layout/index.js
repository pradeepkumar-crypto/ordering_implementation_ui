import React, { useState} from 'react';
import { Header } from '../Header';
import { Sidebar } from '../Sidebar';
import './Layout.styles.scss';
import { routes, actionRoutes } from '../Sidebar/mock';


const Layout = ({ children }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [parentActive, setParentActive] = useState('des-dash');
  const [childActive, setChildActive] = useState('');
  return (
    <div className="layout-container">
      <Sidebar
        isOpen={isOpen}
        setIsOpen={setIsOpen}
        handleClose={() => setIsOpen((prevOpen) => !prevOpen)}
        routes={routes}
        actionRoutes={actionRoutes}
        parentActive={parentActive}
        childActive={childActive}
        isCloseWhenClickOutside={true}
        handleParentRouteChange={(item) => {
          setParentActive(item.value);
          setChildActive(null);
        }}
        handleChildRouteChange={(parent, child) => {
          setParentActive(parent.value);
          setChildActive(child.value);
        }}
      />
      <Header />
      <main className="main-content">
        {children}
      </main>
    </div>
  );
};

export { Layout };
