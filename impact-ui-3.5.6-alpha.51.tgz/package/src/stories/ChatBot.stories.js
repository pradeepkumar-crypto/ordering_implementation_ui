import React, { useState } from "react";
import { fn } from "@storybook/test";
import { ChatBotComponent } from "../components/ChatBot";
import { Header } from "../components/Header";
import { Select } from "../components/Select";
import { DateRangePicker } from "../components/DateRangePicker";
import { DatePicker } from "../components/DatePicker";
import { Table } from "../components/Table";
import { options } from "../mock";

export default {
  title: "Components/ChatBot",
  component: ChatBotComponent,
  tags: ["autodocs"],
  parameters: {
    layout: "centered",
    docs: {
      description: {
        component:
          "ChatBot is a component that allows users to chat with a bot.",
      },
    },
  },
  argTypes: {
    userName: {
      control: { type: "text" },
    },
    isChatBotOpen: {
      control: { type: "boolean" },
    },
    setIsChatBotOpen: {
      control: { type: "function" },
    },
    conversation: {
      control: { type: "array" },
    },
    // formComponent: {
    //   control: { type: "function" },
    // },
    // tableComponent: {
    //   control: { type: "function" },
    // },
    preDefinedQuestions: {
      control: { type: "array" },
    },
  },
};

const tableComponent = () => {
  return (
    <Table
      columnDefs={[
        {
          field: "make",
        },
        {
          field: "model",
        },
        {
          field: "price",
          pinned: "left",
        },
        {
          field: "electric",
        },
        {
          field: "electric0",
        },
        {
          field: "electric1",
        },
        {
          field: "electric2",
          pinned: "right",
        },
        {
          field: "electric3",
        },
        {
          field: "electric4",
        },
        {
          field: "electric5",
        },
      ]}
      onContextualFilterClick={() => {}}
      onNumberFormatChange={() => {}}
      rowData={[
        {
          electric: true,
          electric0: true,
          electric1: "kunal",
          electric2: "Patel",
          electric3: "Bangalore",
          electric4: "Karnataka",
          electric5: "India",
          make: "Tesla",
          model: "Model Y",
          price: 64950,
        },
        {
          electric: true,
          electric0: true,
          electric1: "kunal",
          electric2: "Patel",
          electric3: "Bangalore",
          electric4: "Karnataka",
          electric5: "India",
          make: "Ford",
          model: "F-Series",
          price: 33850,
        },
        {
          electric: true,
          electric0: true,
          electric1: "kunal",
          electric2: "Patel",
          electric3: "Bangalore",
          electric4: "Karnataka",
          electric5: "India",
          make: "maruti",
          model: "dhoni",
          price: 29600,
        },
        {
          electric: true,
          electric0: true,
          electric1: "kunal",
          electric2: "Patel",
          electric3: "Bangalore",
          electric4: "Karnataka",
          electric5: "India",
          make: "Toyota",
          model: "dhoni",
          price: 29600,
        },
        {
          electric: true,
          electric0: true,
          electric1: "kunal",
          electric2: "Patel",
          electric3: "Bangalore",
          electric4: "Karnataka",
          electric5: "India",
          make: "Toyota",
          model: "dhoni",
          price: 29600,
        },
        {
          electric: true,
          electric0: true,
          electric1: "kunal",
          electric2: "Patel",
          electric3: "Bangalore",
          electric4: "Karnataka",
          electric5: "India",
          make: "Toyota",
          model: "Corolla",
          price: 29600,
        },
        {
          electric: true,
          electric0: true,
          electric1: "kunal",
          electric2: "Patel",
          electric3: "Bangalore",
          electric4: "Karnataka",
          electric5: "India",
          make: "Toyota",
          model: "Corolla",
          price: 29600,
        },
        {
          electric: true,
          electric0: true,
          electric1: "kunal",
          electric2: "Patel",
          electric3: "Bangalore",
          electric4: "Karnataka",
          electric5: "India",
          make: "Toyota",
          model: "Corolla",
          price: 29600,
        },
      ]}
      tableHeader="Frozen Columns (Left & Right)"
      hideMarginBottom
    />
  );
};

const formComponent = () => {
  const [open1, setOpen1] = useState(false);
  const [currentOptions1, setCurrentOptions1] = useState(options);
  const [selectedOptions1, setSelectedOptions1] = useState([]);
  const [isSelectAll1, setIsSelectAll1] = useState(false);
  const [startDate, setStartDate] = useState(null);
  const [endDate, setEndDate] = useState(null);
  const [selectedDate, setSelectedDate] = useState(null);

  return (
    <>
      <Select
        label="label"
        labelOrientation="top"
        name="name"
        placeholder="select.."
        isRequired
        isMulti
        isWithSearch
        // isClearable
        toggleSelectAll
        isOpen={open1}
        setIsOpen={setOpen1}
        currentOptions={currentOptions1}
        setCurrentOptions={setCurrentOptions1}
        initialOptions={options}
        selectedOptions={selectedOptions1}
        setSelectedOptions={setSelectedOptions1}
        isSelectAll={isSelectAll1}
        setIsSelectAll={setIsSelectAll1}
        minWidth={"100%"}
        withPortal={true}
      />
      <DateRangePicker
        label="Date Range Selector"
        showMonthYearSelect
        showWeekNumbers
        isRequired
        startDate={startDate}
        setStartDate={setStartDate}
        endDate={endDate}
        setEndDate={setEndDate}
        handleDatesChange={(startDate, endDate) => {
          setStartDate(startDate);
          setEndDate(endDate);
        }}
        displayFormat="DD-MM-YYYY"
        startDateInputProps={{ label: "StartDate", name: "startDate" }}
        endDateInputProps={{ label: "EndDate", name: "endDate" }}
        onSecondaryButtonClick={() => {
          setStartDate(new Date());
          setEndDate(new Date());
        }}
        handleStartDateFocus={(setFocusedInput) => {
          console.log("clicked start");
        }}
        handleEndDateFocus={(setFocusedInput) => {
          console.log("clicked end");
        }}
        startDateOffset={(day) => {
          let days = day.diff(startDate, "days");
          if (startDate && days > 0) {
            return startDate.startOf("week");
          }
          return day.startOf("week");
        }}
        endDateOffset={(day) => {
          // if (props?.maxEightWeekSelection) {
          //   //adding this case for custom selection range, always to maintain a fixed week range
          //   return day.add(props?.selectionRange, "week");
          // }
          return day.endOf("week");
        }}
      />
      <DatePicker
        displayFormat="DD-MM-YYYY"
        handleDateChange={() => {}}
        label="Date Picker with single month"
        labelOrientation="top"
        onPrimaryButtonClick={() => {}}
        onSecondaryButtonClick={() => {}}
        onTertiaryButtonClick={() => {}}
        placeholder="Select Date"
        portalContainer={document.body}
        selectedDate={selectedDate}
        setSelectedDate={setSelectedDate}
        showMonthYearSelect
        showWeekNumbers
      />
    </>
  );
};

const ChatBot = (args) => {
  const [isChatBotOpen, setIsChatBotOpen] = useState(false);
  return (
    <>
      <Header handleChatBotClick={() => setIsChatBotOpen(!isChatBotOpen)} />
      <ChatBotComponent
        {...args}
        isChatBotOpen={isChatBotOpen}
        setIsChatBotOpen={setIsChatBotOpen}
        formComponent={formComponent()}
        tableComponent={tableComponent()}
      />
    </>
  );
};

export const Default = (args) => <ChatBot {...args} />;

Default.args = {
  userName: "Himanshu",
  isChatBotOpen: true,
  setIsChatBotOpen: fn(),
  conversation: [],
};
