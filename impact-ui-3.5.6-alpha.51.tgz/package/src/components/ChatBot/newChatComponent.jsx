import React from "react";
import ChatInput from "./chatInput";
import SunIcon from "../../assets/sun.png";
import CloseIcon from "../../assets/close.svg";
import SmartBotIcon from "../../assets/smartBotAlan.svg";
import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown";
import ClearIcon from "@mui/icons-material/Clear";
import { Button } from "../Button";

export const NewChatComponent = ({
  onClose,
  userName,
  inputValue,
  setInputValue,
  setIsNewChat,
}) => {
  const [loading, setLoading] = React.useState(true);
  React.useEffect(() => {
    const timer = setTimeout(() => setLoading(false), 450);
    return () => clearTimeout(timer);
  }, []);
  return (
    <>
      <div className="chatbot-component-header">
        <Button
          className="chatbot-component-header-dropdown"
          icon={<KeyboardArrowDownIcon size="small" />}
          iconPlacement="right"
          size="large"
          type="default"
          variant="text"
        >
          Module
        </Button>
        <Button
          className="chatbot-component-header-close-icon"
          onClick={onClose}
          icon={<ClearIcon />}
          iconPlacement="left"
          size="large"
          type="default"
          variant="text"
        />
      </div>
      <div className="chatbot-component-body">
        <div className="chatbot-component-body-container">
          <div
            className={`chatbot-component-body-icon${
              loading ? " rotating" : ""
            }`}
          >
            <img src={SmartBotIcon} />
          </div>
          <div className="chatbot-component-body-text">
            <span className="chatbot-component-body-text-title">
              Good Morning{" "}
              <span className="chatbot-component-body-text-username">
                {userName}!
              </span>
              <img src={SunIcon} alt="sun" style={{}} />
            </span>
            <span className="chatbot-component-body-text-description">
              I am Alan, how can I help you today?
            </span>
          </div>
          <div className="chatbot-component-body-input-container">
            <ChatInput
              inputValue={inputValue}
              setInputValue={setInputValue}
              setIsNewChat={setIsNewChat}
            />
          </div>
        </div>
      </div>
    </>
  );
};
