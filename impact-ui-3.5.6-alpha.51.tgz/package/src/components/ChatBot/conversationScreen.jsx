import React, { useState, useEffect } from "react";
import { Button } from "../Button";
import ClearIcon from "@mui/icons-material/Clear";
import SaveOutlinedIcon from "@mui/icons-material/SaveOutlined";
import SmartBotIcon from "../../assets/smartBotAlan.svg";
import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown";
import CloseThreadIcon from "../../assets/close.svg";
import HomeIcon from "../../assets/chat-home-icon.svg";
import ChatInput from "./chatInput";
import ChatIconCircle from "../../assets/chat-icon-circle.svg";

export const ConversationScreen = ({
  inputValue,
  setInputValue,
  setIsNewChat,
  isFormComponent = true,
  isTableComponent = true,
  formComponent,
  tableComponent,
  containerWidth,
}) => {
  const [input, setInput] = useState("");
  return (
    <div className="conversation-screen-container">
      {/* Conversation header starts here  */}

      <div className="conversation-screen-container-header">
        {/* left logo and arrow starts here  */}

        <div className="left_logo_arrow_container">
          <div className="conversation_chatbot_logo_container">
            <img src={SmartBotIcon} />
          </div>
          <div className="menu_arrow">
            <Button
              icon={<KeyboardArrowDownIcon />}
              iconPlacement="right"
              size="small"
              type="default"
              variant="text"
            />
          </div>
        </div>

        {/* left logo and arrow ends here  */}

        {/* Center options stars here  */}

        <div className="center_options_container">
          <div className="left_tabs_container">
            <ul>
              <li className="home active">
                <img src={HomeIcon} />
              </li>
              <li className="">
                Thread 1
                <span className="close_thread">
                  <img src={CloseThreadIcon} />
                </span>
              </li>

              <li>
                Thread 2
                <span className="close_thread">
                  <img src={CloseThreadIcon} />
                </span>
              </li>
            </ul>
          </div>
          <div className="right_info_container"></div>
        </div>

        {/* Center options ends here  */}

        {/* Right close save icon starts here  */}

        <div className="right_close_save_icon_container">
          <div className="save_icon_container">
            <Button
              icon={<SaveOutlinedIcon />}
              iconPlacement="left"
              size="small"
              type="default"
              variant="text"
            />
          </div>

          <div className="close_icon_container">
            <Button
              icon={<ClearIcon />}
              iconPlacement="left"
              size="small"
              type="default"
              variant="text"
            />
          </div>
        </div>

        {/* Right close icon ends here  */}
      </div>

      {/* Conversation header ends here  */}

      {/* Conversation body starts here  */}

      <div className="conversation-body-container">
        <div className="time_stamp_badge_chat_container">
          <div className="time_stamp_badge_chat">Today</div>
        </div>

        {/* User chat starts here  */}

        <div className="user_chat_messages_container">
          <div className="user_chat_message">
            <div className="user_chat_message_text">
              I want to know the gross revenue of stores
            </div>
            <div className="time_chat">10:30 AM</div>
          </div>
        </div>

        {/* User chat ends here  */}

        {/* Assistant chat starts here  */}

        <div className="assistant_chat_messages_container ">
          <div className="chat_logo_circle"></div>

          {/* loading icon */}
          <div className="loading_messages dis_none">
            <span className="dot"></span>
            <span className="dot"></span>
            <span className="dot"></span>
          </div>

          {/* loading icon ends*/}

          <div className="response_main_container">
            {/* assistant with text and Url container */}

            <div className="assistant_with_dropdown_container">
              Parameters used for generating reponse
            </div>

            <div className="assistant_main_container">
              <div className="assistant_text_container">
                For the <span className="bold">Northeast region</span> in the
                last week (LW), during the New Year celebration, the gross
                revenue was $6.75M, which{" "}
                <span className="bold">
                  exceeded the planned target by{" "}
                  <span className="green_text">7.18%</span>
                </span>
                 and showed a significant increase of 9.32% compared to the
                comparable week last year (Week ID: 202340). In the week before
                last (LLW), which coincided with Christmas, the gross revenue
                outperformed the planned target by{" "}
                <span className="bold green_text">7.5%</span> and
                was 9.69% higher compared to the comparable week last year (Week
                ID: 202339). Over the trailing 13 weeks, the gross revenue has
                consistently surpassed expectations, exceeding the planned
                target by <span className="bold red_text">9.04%</span> and
                showing an improvement of 11.13%{" "}
                <span className="bold">
                  compared to the same period last year.
                </span>
              </div>
              <div className="time_chat">10:30 AM</div>
            </div>
            <div className="assistant_actions_container">
              <div className="left_icon_container_action">
                <button className="asst_feedback_buttons good_feedback"></button>
                <button className="asst_feedback_buttons bad_feedback"></button>
                <button className="asst_feedback_buttons speaker"></button>
              </div>
              <div className="button_url_container">
                <button className="asst_feedback_buttons">New Thread</button>
              </div>
              <div className="button_url_container">
                <button className="asst_feedback_buttons">Add to Page</button>
              </div>
            </div>
          </div>
        </div>

        {/* Assistant chat ends here  */}

        {/* User chat starts here  */}

        <div className="user_chat_messages_container">
          <div className="user_chat_message">
            <div className="user_chat_message_text">
              I want to know the gross revenue of stores
            </div>
            <div className="time_chat">10:30 AM</div>
          </div>
        </div>

        {/* User chat ends here  */}

        {/* Assistant chat starts here  */}

        <div className="assistant_chat_messages_container">
          <div className="chat_logo_circle"></div>

          {/* loading icon */}
          <div className="loading_messages dis_none">
            <span className="dot"></span>
            <span className="dot"></span>
            <span className="dot"></span>
          </div>

          {/* loading icon ends*/}

          <div className="response_main_container">
            {/* assistant with Form components */}

            <div
              className={`assistant_main_container ${
                isFormComponent ? "form_container" : ""
              }`}
            >
              <div className="assistant_text_container">
                Form components should go inside this
              </div>
              <div className="assistant_form_container">{formComponent}</div>
              <div className="time_chat">10:30 AM</div>
            </div>
            <div className="assistant_actions_container">
              <div className="left_icon_container_action">
                <button className="asst_feedback_buttons good_feedback"></button>
                <button className="asst_feedback_buttons bad_feedback"></button>
                <button className="asst_feedback_buttons speaker"></button>
              </div>
              <div className="button_url_container">
                <button className="asst_feedback_buttons">New Thread</button>
              </div>
              <div className="button_url_container">
                <button className="asst_feedback_buttons">Add to Page</button>
              </div>
            </div>
          </div>
        </div>

        {/* Assistant chat ends here  */}

        {/* Assistant chat starts here  */}

        <div className="assistant_chat_messages_container">
          <div className="chat_logo_circle"></div>

          {/* loading icon */}
          <div className="loading_messages dis_none">
            <span className="dot"></span>
            <span className="dot"></span>
            <span className="dot"></span>
          </div>

          {/* loading icon ends*/}

          <div className="response_main_container dis_non">
            {/* assistant with Form components */}

            <div
              className={`assistant_main_container ${
                isFormComponent ? "form_container" : ""
              } ${isTableComponent ? "table_container" : ""}`}
              style={{
                width: `${parseInt(containerWidth) - 170}px`,
                maxWidth: `${Math.min(700, parseInt(containerWidth) - 170)}px`,
              }}
            >
              <div className="assistant_text_container">
                Form components should go inside this
              </div>
              <div className="assistant_form_container">{tableComponent}</div>
              <div className="time_chat">10:30 AM</div>
            </div>
            <div className="assistant_actions_container">
              <div className="left_icon_container_action">
                <button className="asst_feedback_buttons good_feedback"></button>
                <button className="asst_feedback_buttons bad_feedback"></button>
                <button className="asst_feedback_buttons speaker"></button>
              </div>
              <div className="button_url_container">
                <button className="asst_feedback_buttons">New Thread</button>
              </div>
              <div className="button_url_container">
                <button className="asst_feedback_buttons">Add to Page</button>
              </div>
            </div>
          </div>
        </div>

        {/* Assistant chat ends here  */}
      </div>

      {/* Conversation body ends here  */}

      {/* Conversation footer starts here  */}

      <div className="conversation-footer-container">
        <ChatInput inputValue={input} setInputValue={setInput} minRows={2} />
      </div>

      {/* Conversation footer ends here  */}
    </div>
  );
};
