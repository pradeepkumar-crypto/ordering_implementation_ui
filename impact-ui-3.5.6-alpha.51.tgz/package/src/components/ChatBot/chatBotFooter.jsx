import React from "react";

export const ChatBotFooter = () => {
  return (
    <div className="chatbot-component-footer">
      <span className="chatbot-component-footer-text">
        Alan can make mistakes.
        <a href="#" className="chatbot-component-footer-text-link">
          learn more
        </a>
      </span>
    </div>
  );
};
