import React, { useState, useEffect } from "react";
import "./chatBot.style.scss";
import CloseIcon from "../../assets/close.svg";
import { ChatBotFooter } from "./chatBotFooter";
import { NewChatComponent } from "./newChatComponent";
import { ConversationScreen } from "./conversationScreen";
import ChatBotLandingScreen from "./chatBotLandingScreen";
import { menuItems } from "./constant";
import { BookMarkPanel } from "./bookMarkPanel";

export const ChatBotComponent = ({
  onClose,
  userName,
  isChatBotOpen,
  setIsChatBotOpen,
  conversation,
  solution,
  formComponent,
  tableComponent,
  preDefinedQuestions,
  addedByYouQuestions,
}) => {
  const [isNewChat, setIsNewChat] = useState(true);
  const [inputValue, setInputValue] = useState("");
  const [isLandingScreen, setIsLandingScreen] = useState(true);
  const [containerWidth, setContainerWidth] = useState("620px");
  const [question, setQuestion] = useState(conversation || []);
  const [answer, setAnswer] = useState(solution);
  const [activeList, setActiveList] = useState("");
  const [isBookMarkPanelOpen, setIsBookMarkPanelOpen] = useState(false);
  const [isHistoryPanelOpen, setIsHistoryPanelOpen] = useState(false);
  const [isPagePanelOpen, setIsPagePanelOpen] = useState(false);
  const [isNotificationPanelOpen, setIsNotificationPanelOpen] = useState(false);

  useEffect(() => {
    if (isChatBotOpen) {
      setTimeout(() => {
        setIsLandingScreen(false);
      }, 2000);
    }
    const resizer = document.querySelector(".resizer");
    let startX, startWidth;

    const onMouseMove = (e) => {
      const dx = e.clientX - startX;
      let newWidth = startWidth - dx;
      if (newWidth > 500 && newWidth < window.innerWidth - 100) {
        setContainerWidth(`${newWidth}px`);
      }
    };

    const onMouseUp = () => {
      document.body.classList.remove("no-select");
      document.removeEventListener("mousemove", onMouseMove);
      document.removeEventListener("mouseup", onMouseUp);
    };

    const onMouseDown = (e) => {
      startX = e.clientX;
      startWidth = document
        .querySelector(".chatbot-component-container")
        .getBoundingClientRect().width;
      document.body.classList.add("no-select");
      document.addEventListener("mousemove", onMouseMove);
      document.addEventListener("mouseup", onMouseUp);
    };

    if (resizer) {
      resizer.addEventListener("mousedown", onMouseDown);
    }

    return () => {
      resizer?.removeEventListener("mousedown", onMouseDown);
    };
  }, [isChatBotOpen, isBookMarkPanelOpen, isHistoryPanelOpen, isPagePanelOpen]);

  const handleCloseChatBot = () => {
    setIsChatBotOpen(false);
    setIsLandingScreen(true);
    onClose?.();
  };

  const handleNewChat = () => {
    setIsNewChat(true);
    setInputValue("");
  };

  const handleBookmark = () => {
    setIsBookMarkPanelOpen(true);
  };

  const handleHistory = () => {
    setActiveList("history");
  };

  const handlePage = () => {
    setActiveList("page");
  };

  const handleNotification = () => {
    setActiveList("notification");
  };

  const handleMenuClick = (item) => {
    setActiveList(item.key === "newChat" ? "" : item.key);
    menuHandlers[item.key]?.();
  };

  const handleCloseLeftPanel = () => {
    setIsBookMarkPanelOpen(false);
    setIsHistoryPanelOpen(false);
    setIsPagePanelOpen(false);
    setActiveList("");
  };

  useEffect(() => {
    let newWidth = containerWidth;
    if (isBookMarkPanelOpen || isHistoryPanelOpen || isPagePanelOpen) {
      const newWidth = Math.max(parseInt(containerWidth), 960);
      setContainerWidth(newWidth);
    } else {
      setContainerWidth(newWidth);
    }
  }, [isBookMarkPanelOpen, isHistoryPanelOpen, isPagePanelOpen]);

  const menuHandlers = {
    newChat: handleNewChat,
    bookmark: handleBookmark,
    history: handleHistory,
    page: handlePage,
    notification: handleNotification,
  };

  return (
    <>
      {isChatBotOpen ? (
        <div className="chatbot-modal-wrapper">
          <div className="resizer" />
          <div
            className="chatbot-component-container"
            style={{ width: containerWidth }}
          >
            {isLandingScreen ? (
              <ChatBotLandingScreen onClose={handleCloseChatBot} />
            ) : (
              <>
                <div
                  className={`chatbot-component-left-side ${
                    isBookMarkPanelOpen || isHistoryPanelOpen || isPagePanelOpen
                      ? "chatbot-component-left-side-open"
                      : ""
                  }`}
                >
                  <div
                    className={`chatbot-component-menu-container ${
                      isBookMarkPanelOpen ||
                      isHistoryPanelOpen ||
                      isPagePanelOpen
                        ? "chatbot-component-menu-container-open"
                        : ""
                    }`}
                  >
                    <div
                      className={`chatbot-component-menu-container-icon ${
                        isBookMarkPanelOpen ||
                        isHistoryPanelOpen ||
                        isPagePanelOpen
                          ? "chatbot-component-menu-container-icon-open"
                          : ""
                      }`}
                    >
                      <ul className="chatbot-component-menu-list">
                        {menuItems.map((item) => (
                          <li
                            key={item.key}
                            className={`${item.className} ${
                              activeList === item.key ? "active" : ""
                            }`}
                            onClick={() => handleMenuClick(item)}
                          >
                            <img
                              src={item.icon}
                              className={item.iconClassName}
                              alt={item.key}
                            />
                          </li>
                        ))}
                      </ul>
                    </div>
                    {isBookMarkPanelOpen && (
                      <BookMarkPanel
                        preDefinedQuestions={preDefinedQuestions}
                        addedByYouQuestions={addedByYouQuestions}
                        onClose={handleCloseLeftPanel}
                      />
                    )}
                  </div>
                </div>
                <div
                  className={`chatbot-component-right-side ${
                    isBookMarkPanelOpen || isHistoryPanelOpen || isPagePanelOpen
                      ? "chatbot-component-right-side-open"
                      : ""
                  }`}
                >
                  {isNewChat ? (
                    <NewChatComponent
                      onClose={handleCloseChatBot}
                      userName={userName}
                      inputValue={inputValue}
                      setInputValue={setInputValue}
                      setIsNewChat={setIsNewChat}
                    />
                  ) : (
                    <ConversationScreen
                      conversation={question}
                      setConversation={setQuestion}
                      solution={answer}
                      inputValue={inputValue}
                      onClose={handleCloseChatBot}
                      formComponent={formComponent}
                      tableComponent={tableComponent}
                      containerWidth={containerWidth}
                    />
                  )}
                  <ChatBotFooter />
                </div>
              </>
            )}
          </div>
        </div>
      ) : null}
    </>
  );
};
