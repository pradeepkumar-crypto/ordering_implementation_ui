import React, { useState } from "react";
import { Box, TextField } from "@mui/material";
import { Button } from "../Button";
import SendIcon from "../../assets/chatBotSendIcon.svg";
import MicIcon from "../../assets/chatBotMicIcon.svg";
import RefreshIcon from "../../assets/chatBotRefreshIcon.svg";

const ChatInput = ({
  inputValue,
  setInputValue,
  setIsNewChat,
  minRows = 4,
}) => {
  return (
    <Box sx={{ position: "relative", width: "100%" }}>
      <TextField
        fullWidth
        placeholder=""
        variant="outlined"
        multiline
        minRows={minRows}
        value={inputValue}
        onChange={(e) => setInputValue(e.target.value)}
        InputProps={{
          sx: {
            borderRadius: "16px",
            backgroundColor: "white",
            "& .MuiOutlinedInput-notchedOutline": {
              borderColor: "#9C27B0",
            },
            "& textarea": {
              paddingRight: "72px", // add space so text doesn't go under icons
            },
            "& .MuiOutlinedInput-root": {
              padding: "5px",
            },
          },
        }}
      />

      {/* Icons container positioned bottom-right */}
      <Box
        sx={{
          position: "absolute",
          bottom: 15,
          right: 8,
          display: "flex",
          gap: 1,
        }}
      >
        <Button
          icon={<img src={RefreshIcon} />}
          iconPlacement="left"
          size="large"
          type="default"
          variant="url"
        />
        <Button
          className=""
          icon={<img src={MicIcon} />}
          iconPlacement="left"
          size="large"
          type="default"
          variant="tertiary"
        />
        <Button
          icon={<img src={SendIcon} />}
          iconPlacement="left"
          size="large"
          type="default"
          variant="primary"
          onClick={() => setIsNewChat(false)}
          disabled={inputValue.length === 0}
        />
      </Box>
    </Box>
  );
};

export default ChatInput;
