import React from "react";
import CloseIcon from "../../assets/close.svg";
import { Button } from "../Button";
import ClearIcon from "@mui/icons-material/Clear";

const ChatBotLandingScreen = ({ onClose }) => (
  <div className="chatbot-landing-screen-container">
    <div className="chatbot-landing-screen-container-close-icon">
      <Button
        className="chatbot-component-header-close-icon"
        onClick={onClose}
        icon={<ClearIcon />}
        iconPlacement="left"
        size="large"
        type="default"
        variant="text"
      />
    </div>
    <div className="chatbot-landing-screen-container-circle-1" />
    <div className="chatbot-landing-screen-container-circle-2" />
  </div>
);

export default ChatBotLandingScreen;
