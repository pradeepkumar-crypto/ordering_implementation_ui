import PageIcon from "../../assets/pageIcon.svg";
import HistoryIcon from "../../assets/historyIcon.svg";
import NewChatIcon from "../../assets/newChatIcon.svg";
import BookMarkIcon from "../../assets/bookmarkIcon.svg";
import NotificationIcon from "../../assets/bell.svg";

export const menuItems = [
  {
    key: "newChat",
    icon: NewChatIcon,
    className: "chatbot-component-menu-container-icon-new-chat",
  },
  {
    key: "bookmark",
    icon: BookMarkIcon,
  },
  {
    key: "history",
    icon: HistoryIcon,
  },
  {
    key: "page",
    icon: PageIcon,
  },
  {
    key: "notification",
    icon: NotificationIcon,
    iconClassName: "chatbot-component-menu-container-icon-notification",
  },
];
