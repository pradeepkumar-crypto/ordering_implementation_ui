import React, { useState, useEffect } from "react";
import { Button } from "../Button";
import "./EmptyState.styles.scss";
import emptyState1 from "../../assets/emptyState1.png";
import emptyState2 from "../../assets/emptyState2.png";
import emptyState3 from "../../assets/emptyState3.png";
import emptyState4 from "../../assets/emptyState4.png";
import emptyState5 from "../../assets/emptyState5.png";
import emptyState6 from "../../assets/emptyState6.png";
const images = [
  emptyState1,
  emptyState2,
  emptyState3,
  emptyState4,
  emptyState5,
  emptyState6,
];

export function EmptyState({
  heading,
  description,
  secondaryButtonLabel,
  onSecondaryButtonClick,
  primaryButtonLabel,
  onPrimaryButtonClick,
  emptyStateIcon = null,
  emptyStateBottomOptions = null,
}) {
  const [prevImage, setPrevImage] = useState(null);
  const [currentImage, setCurrentImage] = useState(0);

  useEffect(() => {
    let randomIndex = Math.floor(Math.random() * images.length);
    // Prevent consecutive repeat
    if (prevImage !== null && randomIndex === prevImage) {
      randomIndex = (randomIndex + 1) % images.length;
    }
    setCurrentImage(randomIndex);
    setPrevImage(randomIndex);
  }, []);

  return (
    <div className="impact_emptystate">
      <div
        className={`impact_center_svg ${
          emptyStateIcon ? "impact_center_svg_with_icon" : ""
        }`}
        style={{
          backgroundImage: `url(${images[currentImage]})`,
        }}
      >
        {emptyStateIcon}
      </div>
      <div className="impact_heading">{heading}</div>
      <div className="impact_paragraph">{description}</div>
      <div className="bottom_cta_container">
        {/* Both the buttons needs to be replaced with design system buttons */}
        {secondaryButtonLabel && (
          <Button
            className="secondary_btn"
            variant="secondary"
            onClick={onSecondaryButtonClick}
          >
            {secondaryButtonLabel}
          </Button>
        )}
        {primaryButtonLabel && (
          <Button className="primary_btn" onClick={onPrimaryButtonClick}>
            {primaryButtonLabel}
          </Button>
        )}
        {emptyStateBottomOptions}
      </div>
    </div>
  );
}
